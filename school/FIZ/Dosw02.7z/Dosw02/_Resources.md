[Beginner Guide, focused on voltage](https://www.hioki.com/euro-en/learning/electricity/voltage.html)
[Youtube Video Beginner Guide (Polish)](https://www.youtube.com/watch?v=zWL6LskZmZc&list=PL_-my4zBZrPHAc5lg37WhtAFmC3dfR0Ih&index=1)
[Current (Beginner Guide)](https://www.fluke.com/en/learn/blog/electrical/what-is-current)
[Kirchoff's Laws 'deep dive'](https://isaacphysics.org/concepts/cp_kirchhoffs_laws?stage=all)
[Joule's Law](https://resources.pcb.cadence.com/blog/2023-joules-law-of-electric-heating)

# Very Short and Useful Videos
[Ammeter](https://www.youtube.com/watch?v=2tCLLPnGnPg)
[Voltmeter](https://www.youtube.com/watch?v=dWZbbbkKXOg)