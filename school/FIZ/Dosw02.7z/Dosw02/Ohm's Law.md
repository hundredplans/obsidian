- Describes relation between [[Voltage]], [[Current]] & [[school/FIZ/Dosw02/Resistance|Resistance]]
- I = U / R
- To quickly calculate form a pyramid and cover whatever you want to calculate
```
  U
I   R
```