# Meta
[[school/FIZ/Dosw02/_Resources|_Resources]]
[[Translation]]
[[to]]
# General
[[Electricity]]
[[Ohm's Law]]
- [[Voltage]]
	- [[Kirchoffs Second Law]]
	- [[Voltmeter]]
	- [[Voltage Fluctuation]]
	- [[Light Bulb Max Voltage]]
- [[Current]]
	- [[Kirchoffs First Law]]
	- [[Ammeter]]
- [[Resistance]]
	- [[Resistor]]
		- [[Joules Law]]!

[[schematic_cheat_sheet.png]]
