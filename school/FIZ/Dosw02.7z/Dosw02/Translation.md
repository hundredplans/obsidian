Napiecie -> Voltage
Prad -> Current
Opor -> Resistance

Napiecie Zminonowe -> [[Light Bulb Max Voltage]]