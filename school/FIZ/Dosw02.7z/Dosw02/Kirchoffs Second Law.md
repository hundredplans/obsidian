# Kirchoffs Second Law / Kirchoffs Voltage Law
- The [[Voltage]] in a closed circuit is equal to zero in totality
 - ∑<sub>i</sub> V<sub>i</sub>​=0