- Create [[Resistance]]
- Limits current by converting the electricity to heat ([[Joule's Law]])
- Explained with Resistance and Power Loss (parameteres)
# Resistance
- Defined on a resistor by the colored belts
- Find a graph / table that shows what it means to read it

# Power Loss
- Bigger?