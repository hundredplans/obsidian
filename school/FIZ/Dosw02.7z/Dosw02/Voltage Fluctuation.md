- Fluctuations in the voltage of a lightbulb over time
- Spikes can occur due to lightning strikes (seems unlikely)
- Dips can occur due to high demand on circuit (shown by dimming)
- Fluctuation occurs due to poor power quality (flickering)

- All of these affect the perfomance, stability and lifespan of light bulbs (why do we need to know this?)