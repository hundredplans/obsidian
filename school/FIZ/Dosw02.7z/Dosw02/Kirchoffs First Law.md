# First Law / Current Rule
- The sum of currents at a meeting point is zero
	- As the currents flowing towards it and against it are equal
- The sum of the current after passing through two parallel resistors and meeting is the same as the current passing through one resistor with the Resistance of both resistors combined