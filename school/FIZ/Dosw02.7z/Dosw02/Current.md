- Always measured at one point
- I, in amps (A) *-> Symbol*
- How fast electricity moves
	- How many electrons are moving past a point in 1 seconds
# Direct Current (DC/Napiecie Stale)
- Indicated by thick line with three smaller lines under it
- Flows with no change to magnitude or direction of current