- How difficult it is for electricity to flow
- As it increases so does [[Voltage]]
- The lesser it is the more [[Current]] can pass
- Symbolised with R (Ω - Ohm)

[[Resistor]]
[[Ohm's Law]]